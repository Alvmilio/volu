import React, { useEffect, useState } from "react";
import axios from "axios";
import CanvasJSReact from '../canvasjs.react';
var CanvasJS = CanvasJSReact.CanvasJS;
var CanvasJSChart = CanvasJSReact.CanvasJSChart;


export default function ReporteVentas() {
  const [ventas = [], setVentas] = useState();
  const [fecha_inicial = [], setFechaIni] = useState();
  const [fecha_final = [], setFechaFin] = useState();
  const [vendedor = [], setVendedorFiltro] = useState();
  const [tipo_rango = [], setTipoRango] = useState();
  const [vendedores = [], setVendedores] = useState();
  const [opc_barras = [], setBarras] = useState();
  
  var data = [];


  useEffect(() => {
    axios
      .get(
        
        "http://18.223.121.116:4000/usuario/getVendedores"
        
      )
      .then((res) => {
        console.log(res.data);
        setVendedores(res.data);
      });
  }, []);


  function getVentasVendedor(){
    axios
    .post(
      
      "http://18.223.121.116:4000/reporte/cantVentas",
      {
        vendedor:vendedor
      }
      
    )
    .then((res) => {
      console.log("las ventas son:");
      console.log(ventas);
      console.log("el vendedor es:");
      console.log(vendedor);
      setVentas(res.data);
      setBarras(generarGraficas(fecha_inicial,fecha_final, tipo_rango, ventas));
    });
    console.log("op_barras");
    console.log(opc_barras);
    
  }
  


  //PIE
  const options_pie = {
    animationEnabled: true,
    exportEnabled: true,
    theme: "dark2", // "light1", "dark1", "dark2"
    title:{
      text: "Trip Expenses"
    },
    data: [{
      type: "pie",
      indexLabel: "{label}: {y}%",		
      startAngle: -90,
      dataPoints: [
        { y: 20, label: "Airfare" },
        { y: 24, label: "Food & Drinks" },
        { y: 20, label: "Accomodation" },
        { y: 14, label: "Transportation" },
        { y: 12, label: "Activities" },
        { y: 10, label: "Misc" }	
      ]
    }]
  }
  //DOUGHNUT
  const options_doughnut = {
    animationEnabled: true,
    title: {
      text: "Customer Satisfaction"
    },
    subtitles: [{
      text: "71% Positive",
      verticalAlign: "center",
      fontSize: 24,
      dockInsidePlotArea: true
    }],
    data: [{
      type: "doughnut",
      showInLegend: true,
      indexLabel: "{name}: {y}",
      yValueFormatString: "#,###'%'",
      dataPoints: [
        { name: "Unsatisfied", y: 5 },
        { name: "Very Unsatisfied", y: 31 },
        { name: "Very Satisfied", y: 40 },
        { name: "Satisfied", y: 17 },
        { name: "Neutral", y: 7 }
      ]
    }]
  }

  const lista_vendedores = vendedores.map((element) => {
    {
      return (
        <option>{element.nombre}</option>
      );
    }
  });

  return (
    <div>
     <h2 className="datos text-secondary" align="center">
        {" "}
        Reporte Ventas
      </h2>
      <div class="form-group col-6">
        <label for="exampleFormControlSelect2">fecha inicial</label>
        <input
                type="date"
                class="form-control"
                id="fecha_ini"
                onChange={(event) => setFechaIni(event.target.value)}
              />
        <label for="exampleFormControlSelect2">fecha final</label>
        <input
                type="date"
                class="form-control"
                id="fecha_fin"
                onChange={(event) => setFechaFin(event.target.value)}
              />
        <label for="exampleFormControlSelect1">Vendedor</label>
            <select
              class="form-control"
              id="vendedor"
              onChange={(event) => setVendedorFiltro(event.target.selectedIndex)}
            >
              <option>Seleccione Vendedor</option>
             {lista_vendedores}
            </select>
        <label for="exampleFormControlSelect1">Filtro de Rango</label>
          <select
            class="form-control"
            id="vendedor"
            onChange={(event) => setTipoRango(event.target.selectedIndex-1)}
          >
            <option>Seleccione Tipo de rango...</option>
            <option>Dias</option>
            <option>Semana</option>
            <option>Mes</option>
          </select>
      </div>

      <button className="btn-primary" onClick={() =>getVentasVendedor()}>
      Generar Graficas
      </button>
      <button className="btn-primary" onClick={() =>setBarras(getVentasVendedor())}>
      actualizar
      </button>
      <CanvasJSChart options = {opc_barras}
            /* onRef = {ref => this.chart = ref} */
        />
        <CanvasJSChart options = {options_pie}
            /* onRef = {ref => this.chart = ref} */
        />
        <CanvasJSChart options = {options_doughnut}
            /* onRef = {ref => this.chart = ref} */
        />
      
    
    </div>
  );
}

function generarGraficas(fecha_inicial,fecha_final, tipo_rango, ventas){
  
  //BARRAS
  var options_bars = {
    animationEnabled: true,
    exportEnabled: true,
    theme: "light2", //"light1", "dark1", "dark2"
    title:{
      text: "Reporte de Ventas"
    },
    data: [{
      type: "column", //change type to bar, line, area, pie, etc
      //indexLabel: "{y}", //Shows y value on all Data Points
      indexLabelFontColor: "#5A5757",
      indexLabelPlacement: "outside",
      dataPoints: [
        {label: "2020/20/11", y:4},
        {label: "2020/20/10", y:3}
      ]
    }]
  }

  var inicio = fecha_inicial.split("-");
  var final = fecha_final.split("-");
  for (let index = 0; index < 3; index++) {
    inicio[index] = parseInt(inicio[index]);
    final[index] = parseInt(final[index]);    
  }

  switch (tipo_rango) {
    case 0:
      console.log("data devuelta");
      console.log(getDataBarrasDias(inicio, final, ventas));
      options_bars.dataPoints = getDataBarrasDias(inicio, final, ventas);
      console.log(options_bars);
      return options_bars;
      break;
    case 1:

      break;
    case 2:

      break;
    default:
      break;
  }
}

function getDataBarrasDias(fecha_inicio, fecha_final, data){
  
  var res = [];

  data.forEach(element => {

    var fecha_label = element.fecha_factura.split("T");
    var aux =  fecha_label[0].split("-"); 
    for (let index = 0; index < 3; index++) {
     aux[index] = parseInt(aux[index]);
    }



    if(fecha_inicio[0] <= aux[0] &&
      fecha_inicio[1] <= aux[1] &&
      fecha_inicio[2] <= aux[2])
      {
        res.push(
          {
            label: fecha_label[0],
            y: element.cantidad
          });
      }
  });

  return res;
}